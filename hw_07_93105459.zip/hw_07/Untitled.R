library(readr)
library(dplyr)
library(ggplot2)
library(highcharter)
library(ggthemes)
library(ggthemr)
library(HistData)
library(psych)
library(Hmisc)
library(car)
library(h2o)
library(caret)
library(corrplot)

murder_suicides = read.csv(file = "data/murder_suicide.csv")

source(file = "unbalanced_functions.R")

############################       1

ms = murder_suicides[, c("Education2003Revision", "EducationReportingFlag", "AgeType", "AgeRecode27", "MaritalStatus", "MannerOfDeath", "Autopsy", "PlaceOfInjury", "RaceRecode5")]
ms = ms %>% filter(AgeType == 1 & EducationReportingFlag == 1)
AgeType = which(colnames(ms) == "AgeType")
EducationReportingFlag = which(colnames(ms) == "EducationReportingFlag")
ms = subset(x = ms, select = -c(AgeType, EducationReportingFlag))
ms = ms %>% mutate_all(as.factor)
ms = ms %>% na.omit()
new_ms = data.matrix(ms)
y = cor(new_ms)
corrplot(y)


new_ms = ms[sample(nrow(ms)),]
new_ms = new_ms %>% head(2000)

scatterplotMatrix(new_ms)


################################  2

#murder_suicides = murder_suicides %>% mutate_all(as.factor)
chisq.test(x = murder_suicides$MannerOfDeath, y = murder_suicides$MethodOfDisposition)

chisq.test(x = murder_suicides$MannerOfDeath, y = murder_suicides$Sex)

chisq.test(x = murder_suicides$MannerOfDeath, y = murder_suicides$RaceRecode5)

chisq.test(x = murder_suicides$MannerOfDeath, y = murder_suicides$Education2003Revision)

chisq.test(x = murder_suicides$MannerOfDeath, y = murder_suicides$AgeRecode27)

################################  3


model = glm(MannerOfDeath ~ Education2003Revision + AgeRecode27 + MaritalStatus + Autopsy + PlaceOfInjury + RaceRecode5, data = ms, family = binomial(link = 'logit'))
summary(model)


##################################   4

ms = ms %>% mutate(preds = predict(model, type = 'response'))

par(mfrow=c(2,2))
plot(model)

ggplot(ms, aes(preds, color = as.factor(MannerOfDeath))) + 
  geom_density( size = 1 ) +
  ggtitle("Dataset Predicted Score" ) + 
  scale_color_economist(name = "data", labels = c("Suicide", "Murder")) +
  xlab("Predictions") + ylab("Density")

table(ms$MannerOfDeath, ifelse(fitted(model)>0.5,1,0)) %>% plot()


##################################   5


ms = murder_suicides[, c("Education2003Revision", "EducationReportingFlag", "AgeType", "AgeRecode27", "MaritalStatus", "MannerOfDeath", "Autopsy", "PlaceOfInjury", "RaceRecode5")]
ms = ms %>% filter(AgeType == 1 & EducationReportingFlag == 1)
AgeType = which(colnames(ms) == "AgeType")
EducationReportingFlag = which(colnames(ms) == "EducationReportingFlag")
ms = subset(x = ms, select = -c(AgeType, EducationReportingFlag))
ms = ms %>% mutate_all(as.factor)
ms = ms %>% na.omit()
ms = ms[sample(nrow(ms)),]
ms = ms %>% mutate(Suicide = ifelse(MannerOfDeath == 2, 1, 0))
ms = ms %>% mutate(Homicide = 1-Suicide)

index = sample(x = 1:nrow(ms), size = 0.8*nrow(ms), replace = F)
train = ms[index,] 
test =  ms[-index,]

model = glm(MannerOfDeath ~ Education2003Revision + AgeRecode27 + MaritalStatus + Autopsy + PlaceOfInjury + RaceRecode5, data = train, family = binomial(link = 'logit'))
summary(model)

train$preds = predict( model, newdata = train, type = "response" )
test$preds  = predict( model, newdata = test , type = "response" )
train = train %>% mutate(prediction = ifelse(preds >= 0.5, 1, 0))
test = test %>% mutate(prediction = ifelse(preds >= 0.5, 1, 0))

P = 0
N = 0
TP = 0
TN = 0
FP = 0
FN = 0

for (i in 1:nrow(test)) {
  if (test[i, "Homicide"] == 1)
    P = P + 1
  else
    N = N + 1
  if (test[i, "Homicide"] == 1 & test[i, "prediction"] == 1)
    TP = TP + 1
  if (test[i, "Homicide"] == 0 & test[i, "prediction"] == 1)
    FP = FP + 1
  if (test[i, "Homicide"] == 0 & test[i, "prediction"] == 0)
    TN = TN + 1
  if (test[i, "Homicide"] == 1 & test[i, "prediction"] == 0)
    FN = FN + 1
}

Accuracy = (TP+TN) / (P+N)
FPR = 1 - TN/N
TPR = TP/P

cm_info = ConfusionMatrixInfo(data = test, predict = "preds", actual = "Homicide", cutoff = .5)
cm_info$plot



##################################   6

accuracy_info = AccuracyCutoffInfo(train = train, test = test, predict = "preds", actual = "Homicide")
accuracy_info$plot


##################################   7

cost_fp = 300
cost_fn = 200
roc_info = ROCInfo(data = cm_info$data, predict = "predict", actual = "actual", cost.fp = cost_fp, cost.fn = cost_fn )
grid.draw(roc_info$plot)


##################################   8

ms = murder_suicides[, c("Education2003Revision", "EducationReportingFlag", "AgeType", "AgeRecode27", "MaritalStatus", "MannerOfDeath", "Autopsy", "PlaceOfInjury", "RaceRecode5")]
ms = ms %>% filter(AgeType == 1 & EducationReportingFlag == 1)
AgeType = which(colnames(ms) == "AgeType")
EducationReportingFlag = which(colnames(ms) == "EducationReportingFlag")
ms = subset(x = ms, select = -c(AgeType, EducationReportingFlag))
ms = ms %>% mutate_all(as.factor)
ms = ms %>% na.omit()

h2o.init()
h2oms = as.h2o(ms)

chglm = h2o.glm(y = "MannerOfDeath", x = c("Education2003Revision", "AgeRecode27", "MaritalStatus", "Autopsy", "PlaceOfInjury", "RaceRecode5"), training_frame = h2oms, family="binomial", nfolds = 5)

chglm



##################################   9

