library(tm)
library(wordcloud)
library(stringr)
library(readr)
library(dplyr)
library(ngram)
library(ggplot2)
library(highcharter)
library(gutenbergr)
library(wordcloud2)
library(tidytext)

ThePickwickPapers = gutenberg_download(580)
OliverTwist = gutenberg_download(730)
NicholasNickleby = gutenberg_download(967)
TheOldCuriosityShop = gutenberg_download(700)
BarnabyRudge = gutenberg_download(917)
MartinChuzzlewit = gutenberg_download(968)
DombeyandSon = gutenberg_download(821)
DavidCopperfield = gutenberg_download(766)
BleakHouse = gutenberg_download(1023)
HardTimes = gutenberg_download(786)
LittleDorrit = gutenberg_download(963)
ATaleofTwoCities = gutenberg_download(98)
GreatExpectations = gutenberg_download(1400)
OurMutualFriend = gutenberg_download(883)
TheMysteryofEdwinDrood = gutenberg_download(564)

books = list(ThePickwickPapers, OliverTwist, NicholasNickleby, TheOldCuriosityShop, BarnabyRudge, MartinChuzzlewit,
             DombeyandSon, DavidCopperfield, BleakHouse, HardTimes, LittleDorrit, ATaleofTwoCities,
             GreatExpectations, OurMutualFriend, TheMysteryofEdwinDrood)

booksnames = c("ThePickwickPapers", "OliverTwist", "NicholasNickleby", "TheOldCuriosityShop", "BarnabyRudge",
               "MartinChuzzlewit", "DombeyandSon", "DavidCopperfield", "BleakHouse", "HardTimes", "LittleDorrit",
               "ATaleofTwoCities", "GreatExpectations", "OurMutualFriend", "TheMysteryofEdwinDrood")


#################################    1

words = list();
finalwords = data.frame()
for (i in 1:length(books)) {
  words[[i]] = books[[i]] %>%
  str_replace_all("'", "") %>% 
  str_replace_all("\"","") %>% 
  str_replace_all("[[:punct:]]"," ") %>%
  str_to_lower() %>% 
  str_split(pattern = "\\s") %>% 
  unlist() %>% 
  table() %>% 
  as.data.frame(stringsAsFactors = F)
  colnames(words[[i]]) = c("word","count")
  finalwords = rbind(finalwords, words[[i]])
}
finalwords = finalwords %>% group_by(word) %>% summarise(tedad = sum(count))
colnames(finalwords) = c("word", "tedad")
finalwords = finalwords %>%
filter(!str_to_lower(word) %in% stop_words$word) %>% 
filter(str_length(word)>1) %>% 
filter(!str_detect(word,"\\d")) %>%
arrange(desc(tedad))

head(finalwords, 20) %>%
  hchart('column', hcaes(x = word, y = tedad)) %>% 
  hc_add_theme(hc_theme_ffx()) %>%
  hc_xAxis(title = list(text = "Words")) %>% 
  hc_yAxis(title = list(text = "Frequency")) %>% 
  hc_title(text = "Most Used Words")

head(finalwords, 20)
  
##################################     2

temp = head(finalwords, 200)
wordcloud2(data = temp, figPath = "../../../Homeworks/hw_08/images/dickens1_1.png", size = 0.3, color = "black")



############################# 3

words = list()
characters = data.frame()
finalwords = data.frame()
for (i in 1:length(books)) {
  words[[i]] = books[[i]] %>% 
  str_replace_all("'", "") %>% 
  str_replace_all("\"","") %>% 
  str_replace_all("[[:punct:]]"," ") %>% 
  str_split(pattern = "\\s") %>% 
  unlist() %>% 
  table() %>% 
  as.data.frame(stringsAsFactors = F)
  colnames(words[[i]]) = c("word","count")
  temp = words[[i]] %>%
  filter(!str_to_lower(word) %in% stop_words$word) %>% 
  filter(str_length(word)>1) %>% 
  filter(!str_detect(word,"\\d")) %>%
  arrange(desc(count)) %>% 
  mutate(proper = !word %in% str_to_lower(word)) %>%
  filter(proper == TRUE) %>%
  filter(word != 'Sir' & word != 'sir' & word != 'Miss') %>% 
  mutate(Book = booksnames[i])
  characters = rbind(characters, head(temp, 5))
}

characters %>%
group_by(Book) %>% 
mutate(percent = round(100*count/sum(count))) %>% 
hchart("column",hcaes(x = Book, y = percent, group = word)) %>% 
hc_add_theme(hc_theme_ffx())


#####################################   4

positive_words = sentiments %>% filter(sentiment == "positive") %>% select(word)
negative_words = sentiments %>% filter(sentiment == "negative") %>% select(word)
finalwords = data.frame()
finaldataframes = list()
for (i in 1:length(books)) {
  words = books[[i]] %>%
    str_replace_all("'", "") %>% 
    str_replace_all("\"","") %>% 
    str_replace_all("[[:punct:]]"," ") %>%
    str_to_lower() %>% 
    str_split(pattern = "\\s") %>% 
    unlist() %>% 
    table() %>% 
    as.data.frame(stringsAsFactors = F)
  colnames(words) = c("word","count")
  finalwords = words %>% group_by(word) %>% summarise(tedad = sum(count))
  colnames(finalwords) = c("word", "tedad")
  finalwords = finalwords %>%
    filter(!str_to_lower(word) %in% stop_words$word) %>% 
    filter(str_length(word)>1) %>% 
    filter(!str_detect(word,"\\d"))
  poswords = merge(finalwords, positive_words) %>% unique() %>% mutate(type = "pos") %>% arrange(desc(tedad))
  negwords = merge(finalwords, negative_words) %>% unique() %>% mutate(type = "neg") %>% arrange(desc(tedad))
  finaldataframes[[i]] = rbind(poswords %>% head(20), negwords %>% head(20))
  finaldataframes[[i]] = finaldataframes[[i]] %>% arrange(desc(tedad))
}

for (i in 1:length(books)) {
  hc = hchart(finaldataframes[[i]], hcaes(x = word, y = tedad, color = type),  type = "bar") %>% 
    hc_xAxis(title = list(text = "Words")) %>% 
    hc_yAxis(title = list(text = "Frequency")) %>%   
    hc_title(text = booksnames[[i]])
  
  print(hc)
  
  hc = hchart(finaldataframes[[i]], hcaes(x = type, y = tedad, group = word),  type = "bar") %>% 
    hc_xAxis(title = list(text = "Words")) %>% 
    hc_yAxis(title = list(text = "Frequency")) %>%   
    hc_title(text = booksnames[[i]])
  
  print(hc)
  
}



#######################################  5

lesMiserables = gutenberg_download(135)
positive_words = sentiments %>% filter(sentiment == "positive") %>% select(word)
negative_words = sentiments %>% filter(sentiment == "negative") %>% select(word)

words = lesMiserables$text %>%
  str_replace_all("'", "") %>% 
  str_replace_all("\"","") %>% 
  str_replace_all("[[:punct:]]"," ") %>%
  str_to_lower() %>% 
  str_split(pattern = "\\s") %>% 
  unlist() %>% 
  as.data.frame()
colnames(words) = c("word")
words = words %>% 
  filter(!str_to_lower(word) %in% stop_words$word) %>% 
  filter(str_length(word)>1) %>% 
  filter(!str_detect(word,"\\d"))

sz = nrow(words) / 200

res = data.frame(matrix(ncol = 3, nrow = 0))
colnames(res) = c("section", "type", "count")

for (i in 1:200) {
  start = floor((i-1) * sz + 1)
  end = floor(i * sz)
  poscnt = 0
  negcnt = 0
  for (j in start:end) {
    if (words$word[j] %in% positive_words$word)
      poscnt = poscnt + 1
    if (words$word[j] %in% negative_words$word)
      negcnt = negcnt + 1
  }
  res[nrow(res)+1, ] = c(i, "positive", poscnt)
  res[nrow(res)+1, ] = c(i, "negative", negcnt)
}

res$count = as.numeric(res$count)
hchart(res, hcaes(x = res$section, y = res$count, group = res$type), type = 'line')


###########################  6

words = lesMiserables$text %>%
  str_replace_all("'", "") %>% 
  str_replace_all("\"","") %>% 
  str_replace_all("[[:punct:]]"," ") %>%
  str_split(pattern = "\\s") %>% 
  unlist() %>% 
  as.data.frame()
colnames(words) = c("word")
twograms = words %>%
  filter(!str_to_lower(word) %in% stop_words$word) %>% 
  filter(str_length(word)>1) %>% 
  filter(!str_detect(word,"\\d")) %>%
  unlist()
twograms = str_c(twograms, collapse = " ")
twograms = ngram(twograms, n = 2)
twograms = twograms %>% get.phrasetable()
twograms = twograms %>% arrange(desc(freq))
head(twograms, 30) %>% select(ngrams , freq) %>% hchart("column" , hcaes(x = ngrams , y = freq))


#######################################  7

twograms = data.frame()
for (i in 1:length(books)) {
  words = books[[i]]$text %>%
    str_replace_all("'", "") %>% 
    str_replace_all("\"","") %>% 
    str_replace_all("[[:punct:]]"," ") %>%
    str_to_lower() %>%
    str_split(pattern = "\\s") %>% 
    unlist() %>% 
    as.data.frame()
  colnames(words) = c("word")
  tempgrams = words %>%
    #filter(!str_to_lower(word) %in% stop_words$word) %>% 
    filter(str_length(word)>1) %>% 
    filter(!str_detect(word,"\\d")) %>%
    unlist()
  tempgrams = str_c(tempgrams, collapse = " ")
  tempgrams = ngram(tempgrams, n = 2)
  tempgrams = tempgrams %>% get.phrasetable()
  tempgrams = tempgrams %>% filter(str_detect(tempgrams$ngrams, "^(he|she)\\s+"))
  twograms = rbind(twograms, tempgrams)
}

twograms = twograms %>% select(ngrams, freq)
twograms = twograms %>% group_by(ngrams) %>% summarise(cnt = sum(freq))
twograms = twograms %>% mutate(verb = str_replace_all(ngrams, "^(he|she)\\s", ""))
yy = twograms %>% group_by(verb) %>% mutate(tot = sum(cnt))
badverbs = "(had|was|is|would|could|has|did|might|were|should|will|must|never|and|may)"
xx = yy %>% filter(!str_detect(verb, badverbs))
xx %>% arrange(desc(cnt)) %>% head(20) %>% hchart("column", hcaes(x = ngrams, y = cnt)) %>% 
  hc_xAxis(title = list(text = "Verbs")) %>% 
  hc_yAxis(title = list(text = "Frequency")) %>% 
  hc_title(text = "Most Used Verbs")



#######################################  8

indexes = str_which(DavidCopperfield$text, pattern = "CHAPTER")
DavidCopperfieldStats = data.frame(matrix(nrow = 0, ncol = 2))
colnames(DavidCopperfieldStats) = c("chapter", "2-gram")
for (i in 1:(length(indexes)-1)) {
  first = indexes[[i]]
  second = indexes[[i+1]]
  bigrams = DavidCopperfield[c(first:second),] %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>% 
    as.data.frame(stringAsFactors = F)
  DavidCopperfieldStats[nrow(DavidCopperfieldStats)+1, ] = c(i, nrow(bigrams))
}

DavidCopperfieldStats %>%  hchart("column", hcaes(x = chapter, y = `2-gram`)) %>% 
  hc_xAxis(title = list(text = "Chapters")) %>% 
  hc_yAxis(title = list(text = "2-grams")) %>% 
  hc_title(text = "2-grams distribution in David Copperfield book")


indexes = str_which(BarnabyRudge$text, pattern = "Chapter")
BarnabyRudgeStats = data.frame(matrix(nrow = 0, ncol = 2))
colnames(BarnabyRudgeStats) = c("chapter", "2-gram")
for (i in 1:(length(indexes)-1)) {
  first = indexes[[i]]
  second = indexes[[i+1]]
  bigrams = BarnabyRudge[c(first:second),] %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>% 
    as.data.frame(stringAsFactors = F)
  BarnabyRudgeStats[nrow(BarnabyRudgeStats)+1, ] = c(i, nrow(bigrams))
}

BarnabyRudgeStats %>%  hchart("column", hcaes(x = chapter, y = `2-gram`)) %>% 
  hc_xAxis(title = list(text = "Chapters")) %>% 
  hc_yAxis(title = list(text = "2-grams")) %>% 
  hc_title(text = "2-grams distribution in Barnaby Rudge book")



indexes = str_which(DombeyandSon$text, pattern = "CHAPTER")
DombeyandSonStats = data.frame(matrix(nrow = 0, ncol = 2))
colnames(DombeyandSonStats) = c("chapter", "2-gram")
for (i in 1:(length(indexes)-1)) {
  first = indexes[[i]]
  second = indexes[[i+1]]
  bigrams = DombeyandSon[c(first:second),] %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>% 
    as.data.frame(stringAsFactors = F)
  DombeyandSonStats[nrow(DombeyandSonStats)+1, ] = c(i, nrow(bigrams))
}

DombeyandSonStats %>%  hchart("column", hcaes(x = chapter, y = `2-gram`)) %>% 
  hc_xAxis(title = list(text = "Chapters")) %>% 
  hc_yAxis(title = list(text = "2-grams")) %>% 
  hc_title(text = "2-grams distribution in Dombey and Son book")


indexes = str_which(GreatExpectations$text, pattern = "Chapter")
GreatExpectationsStats = data.frame(matrix(nrow = 0, ncol = 2))
colnames(GreatExpectationsStats) = c("chapter", "2-gram")
for (i in 1:(length(indexes)-1)) {
  first = indexes[[i]]
  second = indexes[[i+1]]
  bigrams = GreatExpectations[c(first:second),] %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>% 
    as.data.frame(stringAsFactors = F)
  GreatExpectationsStats[nrow(GreatExpectationsStats)+1, ] = c(i, nrow(bigrams))
}

GreatExpectationsStats %>%  hchart("column", hcaes(x = chapter, y = `2-gram`)) %>% 
  hc_xAxis(title = list(text = "Chapters")) %>% 
  hc_yAxis(title = list(text = "2-grams")) %>% 
  hc_title(text = "2-grams distribution in Great Expectations book")


#######################################  9

AdventuresofHuckleberryFinn = gutenberg_download(76)
ATrampAbroad = gutenberg_download(119)

indexes = str_which(AdventuresofHuckleberryFinn$text, pattern = "CHAPTER")
AdventuresofHuckleberryFinnStats = data.frame(matrix(nrow = 0, ncol = 2))
colnames(AdventuresofHuckleberryFinnStats) = c("chapter", "2-gram")
for (i in 1:(length(indexes)-1)) {
  first = indexes[[i]]
  second = indexes[[i+1]]
  bigrams = AdventuresofHuckleberryFinn[c(first:second),] %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>% 
    as.data.frame(stringAsFactors = F)
  AdventuresofHuckleberryFinnStats[nrow(AdventuresofHuckleberryFinnStats)+1, ] = c(i-42, nrow(bigrams))
}

AdventuresofHuckleberryFinnStats[43:nrow(AdventuresofHuckleberryFinnStats), ] %>%  hchart("column", hcaes(x = chapter, y = `2-gram`)) %>% 
  hc_xAxis(title = list(text = "Chapters")) %>% 
  hc_yAxis(title = list(text = "2-grams")) %>% 
  hc_title(text = "2-grams distribution in Adventures of Huckleberry Finn book")




indexes = str_which(ATrampAbroad$text, pattern = "CHAPTER")
ATrampAbroadStats = data.frame(matrix(nrow = 0, ncol = 2))
colnames(ATrampAbroadStats) = c("chapter", "2-gram")
for (i in 1:(length(indexes)-1)) {
  first = indexes[[i]]
  second = indexes[[i+1]]
  bigrams = ATrampAbroad[c(first:second),] %>% unnest_tokens(bigram, text, token = "ngrams", n = 2) %>% 
    as.data.frame(stringAsFactors = F)
  ATrampAbroadStats[nrow(ATrampAbroadStats)+1, ] = c(i-50, nrow(bigrams))
}

ATrampAbroadStats[51:nrow(ATrampAbroadStats), ] %>%  hchart("column", hcaes(x = chapter, y = `2-gram`)) %>% 
  hc_xAxis(title = list(text = "Chapters")) %>% 
  hc_yAxis(title = list(text = "2-grams")) %>% 
  hc_title(text = "2-grams distribution in A Tramp Abroad book")
