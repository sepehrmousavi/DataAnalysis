library(readr)
library(plyr)
library(dplyr)
library(ggplot2)
library(highcharter)
library(GGally)
library(ggbiplot)
library(EBImage)
library(stringr)
library(tidyr)
library(quantmod)
library(car)


constituents = read.csv(file = "data/constituents.csv")
indexes = read.csv(file = "data/indexes.csv") %>% separate(Date, c("Year", "Month", "Day"), sep = "-")

symbols = constituents$Symbol
companies = list()
companyNames = list()
for (i in 1:nrow(constituents)) {
  address = "data/stock_dfs/"
  address = paste(address, constituents$Symbol[i], ".csv")
  address = str_replace_all(address, " ", "")
  if (file.exists(address)) {
    companies[[i]] = read.csv(file = address) %>% separate(Date, c("Year", "Month", "Day"), sep = "-") %>% mutate(Company = constituents$Symbol[i])
    companyNames[[i]] = constituents$Symbol[i]
  }
}

companies = compact(companies)
companyNames = compact(companyNames)
allCompanies = ldply(companies, data.frame)
allCompanies = allCompanies[, c(10, 1, 2, 3, 4, 5, 6, 7, 8, 9)]
allCompanies = allCompanies %>% arrange(Company, Year, Month, Day)
allCompanies$Open = as.numeric(allCompanies$Open)
allCompanies$High = as.numeric(allCompanies$High)
allCompanies$Low = as.numeric(allCompanies$Low)
allCompanies$Close = as.numeric(allCompanies$Close)
allCompanies$Volume = as.numeric(allCompanies$Volume)
allCompanies$Adj.Close = as.numeric(allCompanies$Adj.Close)

####################################### 1

temp = matrix(ncol = 6)
profits = as.data.frame(temp)
colnames(profits) = c("StartYear", "EndYear", "Duration", "Sector", "Company", "Profit")
for (i in 1:length(companyNames)) {
  name = companyNames[[i]]
  sector = constituents[which(constituents$Symbol == name),]$Sector
  temp = allCompanies[which(allCompanies$Company == name),]
  minYear = min(temp$Year)
  maxYear = max(temp$Year)
  for (k in c(1, 2, 5))
    for (years in minYear:maxYear) {
      startYear = years
      endYear = years + k - 1
      if (endYear <= maxYear) {
        begin = temp[which(temp$Year == startYear), ]
        end = temp[which(temp$Year == endYear), ]
        profit = (end[nrow(end), ]$Close - begin[1, ]$Open) / begin[1, ]$Open * 100
        profits[nrow(profits)+1, ] = c(startYear, endYear, k, as.character(sector), as.character(name), profit)
      }
    }
}

profits = profits %>% na.omit()
profits$Profit = as.numeric(profits$Profit)

x = profits[which(profits$Duration == 1), ] %>% arrange(desc(Profit)) %>% head(10) %>% mutate(CompanyTime = paste(Company,StartYear))
hchart(x, hcaes(x = CompanyTime, y = Profit), type = 'column') %>% 
  hc_xAxis(title = list(text = "Company and Time")) %>% 
  hc_yAxis(title = list(text = "Profit")) %>%   
  hc_title(text = "Top 10 Most Profitable Companies in 1 Year Period")


x = profits[which(profits$Duration == 2), ] %>% arrange(desc(Profit)) %>% head(10) %>% mutate(CompanyTime = paste(Company,StartYear,"-",EndYear))
hchart(x, hcaes(x = CompanyTime, y = Profit), type = 'column') %>% 
  hc_xAxis(title = list(text = "Company and Time")) %>% 
  hc_yAxis(title = list(text = "Profit")) %>%   
  hc_title(text = "Top 10 Most Profitable Companies in 2 Year Period")


x = profits[which(profits$Duration == 5), ] %>% arrange(desc(Profit)) %>% head(10) %>% mutate(CompanyTime = paste(Company,StartYear,"-",EndYear))
hchart(x, hcaes(x = CompanyTime, y = Profit), type = 'column') %>% 
  hc_xAxis(title = list(text = "Company and Time")) %>% 
  hc_yAxis(title = list(text = "Profit")) %>%   
  hc_title(text = "Top 10 Most Profitable Companies in 5 Year Period")

y = profits[which(profits$Duration == 1), ]
x = y %>% group_by(Sector, StartYear) %>% summarise(meanProfit = mean(Profit)) %>% arrange(desc(meanProfit)) %>% head(10) %>% mutate(SectorTime = paste(Sector,StartYear))
hchart(x, hcaes(x = SectorTime, y = meanProfit), type = 'column') %>% 
  hc_xAxis(title = list(text = "Sector and Time")) %>% 
  hc_yAxis(title = list(text = "Profit")) %>%   
  hc_title(text = "Top 10 Most Profitable Sectors in 1 Year Period")



y = profits[which(profits$Duration == 2), ]
x = y %>% group_by(Sector, StartYear, EndYear) %>% summarise(meanProfit = mean(Profit)) %>% arrange(desc(meanProfit)) %>% head(10) %>% mutate(SectorTime = paste(Sector,StartYear,"-",EndYear))
hchart(x, hcaes(x = SectorTime, y = meanProfit), type = 'column') %>% 
  hc_xAxis(title = list(text = "Sector and Time")) %>% 
  hc_yAxis(title = list(text = "Profit")) %>%   
  hc_title(text = "Top 10 Most Profitable Sectors in 2 Year Period")


y = profits[which(profits$Duration == 5), ]
x = y %>% group_by(Sector, StartYear, EndYear) %>% summarise(meanProfit = mean(Profit)) %>% arrange(desc(meanProfit)) %>% head(10) %>% mutate(SectorTime = paste(Sector,StartYear,"-",EndYear))
hchart(x, hcaes(x = SectorTime, y = meanProfit), type = 'column') %>% 
  hc_xAxis(title = list(text = "Sector and Time")) %>% 
  hc_yAxis(title = list(text = "Profit")) %>%   
  hc_title(text = "Top 10 Most Profitable Sectors in 5 Year Period")


####################################### 2

infoCompanies = allCompanies %>% mutate(profit = Close - Open) %>% group_by(Year, Month, Day) %>%
  summarise(profit_percent = (sum(profit < 0)/n()))

sizdah = infoCompanies[infoCompanies$Day == 13, ]
notsizdah = infoCompanies[infoCompanies$Day != 13, ]

t.test(sizdah$profit_percent, notsizdah$profit_percent)


####################################### 3

x = allCompanies %>% group_by(Year, Month, Day) %>% summarise(gardesh = sum(Volume * (Open + Close) / 2))
x = x %>% arrange(desc(gardesh))
print(x[1, ])

####################################### 4


Apple = allCompanies[which(allCompanies$Company == 'AAPL'),]
models = list()
errors = matrix(ncol = 1)
errors = as.data.frame(errors)
colnames(errors) = c("MSE")

for (k in 1:10) {
  temp = Apple
  for (i in 1:k) {
    colname = paste("Day", i, sep = "")
    temp[[colname]] = rep(NA, nrow(temp))
    for (j in ((1+i) : nrow(Apple))) {
      temp[[colname]][j] = Apple[j-i,]$Open
    }
  }
  temp = temp %>% na.omit()
  variables = paste("Day", 1:k, sep = "")
  formula = formula(paste("Open ~ ", paste(variables, collapse = " + ")))
  models[[k]] = lm(formula, data = temp)
  errors[nrow(errors)+1,] = mean(models[[k]]$residuals^2)
}

errors = errors %>% na.omit()
which(errors$MSE == min(errors$MSE))  


######################################   5

temp = allCompanies %>% select(Open, Year, Month, Day, Company) %>% spread(key = "Company", value = "Open") %>% na.omit() %>% select(-Day, -Month, -Year)
pca = prcomp(temp, center = TRUE, scale. = TRUE)
x = summary(pca)
percentage = x$importance %>% data.frame()
percentage["Index",] = c(1:ncol(percentage ))
percentage = percentage %>% t() %>% data.frame()
print(percentage$Cumulative.Proportion[3])
hchart(percentage, hcaes(x = Index, y = Cumulative.Proportion), type = 'line') %>% 
  hc_xAxis(title = list(text = "Principal Component Index")) %>% 
  hc_yAxis(title = list(text = "Cumulative Proportion")) %>%   
  hc_title(text = "Cumulative Proportion vs Princiapl Component Index")


######################################   6

y = constituents
colnames(y) = c("Company", "Name", "Sector")
x = merge(x = allCompanies, y = y, by = "Company", all.x = TRUE)
temp = x %>% group_by(Sector, Year, Month, Day) %>% summarise(Open = mean(Open, na.rm = TRUE))
x = temp %>% spread(key = "Sector", value = "Open") %>% na.omit()
x = merge(x, indexes, all.x = TRUE) %>% na.omit() %>% select(-Day, -Month, -Year)
pca = prcomp(x, center = TRUE, scale. = TRUE)
biplot(pca, cex = 0.8)


#######################################   7

Apple = allCompanies[which(allCompanies$Company == 'AAPL'),]
Apple = Apple[, c(5:10)]
pca = prcomp(Apple, center = TRUE, scale. = TRUE)
z = pca$x %>% as.data.frame()
z = z$PC1
Apple = cbind(Apple, z)
colnames(Apple)[ncol(Apple)] = "PC1"

models = list()
errors = matrix(ncol = 1)
errors = as.data.frame(errors)
colnames(errors) = c("MSE")

for (k in 1:10) {
  temp = Apple
  for (i in 1:k) {
    colname = paste("Day", i, sep = "")
    temp[[colname]] = rep(NA, nrow(temp))
    for (j in ((1+i) : nrow(Apple))) {
      temp[[colname]][j] = Apple[j-i,]$PC1
    }
  }
  temp = temp %>% na.omit()
  variables = paste("Day", 1:k, sep = "")
  formula = formula(paste("Open ~ ", paste(variables, collapse = " + ")))
  models[[k]] = lm(formula, data = temp)
  errors[nrow(errors)+1,] = mean(models[[k]]$residuals^2)
}

errors = errors %>% na.omit()
print(errors)



#######################################   8

tempIndexes = indexes[, c(1:4)]
colname = "profit"
tempIndexes[[colname]] = rep(NA, nrow(tempIndexes))
for (i in 2:nrow(tempIndexes))
  tempIndexes$profit[i] = (tempIndexes$SP500[i] - tempIndexes$SP500[i-1]) / tempIndexes$SP500[i-1] * 100
tempIndexes = tempIndexes %>% na.omit()
density(tempIndexes$profit) %>% hchart() %>% 
  hc_xAxis(title = list(text = "Relative Profit")) %>% 
  hc_yAxis(title = list(text = "Density of Rel Profit")) %>%
  hc_title(text = "Relative Profit of S&P Index Chart")

qqPlot(tempIndexes$profit)





#######################################   9

pic = flip(readImage("images/stock.jpg"))
red.weigth = 0.2989
green.weigth = 0.587
blue.weigth  = 0.114
img = red.weigth * imageData(pic)[,,1] + 
  green.weigth * imageData(pic)[,,2] + blue.weigth  * imageData(pic)[,,3]

image(img, col = grey(seq(0, 1, length = 256)))

pca.img = prcomp(img, scale=TRUE)

x = summary(pca.img)
percentage = x$importance %>% data.frame()
percentage["Index",] = c(1:ncol(percentage ))
percentage = percentage %>% t() %>% data.frame()
print(percentage$Cumulative.Proportion[3])

hchart(percentage, hcaes(x = Index, y = Cumulative.Proportion), type = 'line') %>% 
  hc_xAxis(title = list(text = "Principal Component Index")) %>% 
  hc_yAxis(title = list(text = "Variance Explained")) %>%   
  hc_title(text = "Variance Explained vs Princiapl Component Index")

start = min(which(percentage$Cumulative.Proportion >= 0.99))

chosen.components = 1:start
feature.vector = pca.img$rotation[,chosen.components]

compact.data = t(feature.vector) %*% t(img)

approx.img = t(feature.vector %*% compact.data) 

image(approx.img, col = grey(seq(0, 1, length = 256)))

imageSizes = matrix(ncol = 2, nrow = nrow(percentage))
imageSizes = imageSizes %>% as.data.frame()
colnames(imageSizes) = c("Index", "Size")
imageSizes$Index = 1:nrow(percentage)

for (i in 1:nrow(percentage)) {
  chosen.components = 1:i
  feature.vector = pca.img$rotation[,chosen.components]
  compact.data = t(feature.vector) %*% t(img)
  approx.img = t(feature.vector %*% compact.data) 
  approx.img %>% writeImage(file = "images/x.jpg", quality = 100)
  imageSizes$Size[i] = file.info("images/x.jpg")$size %>% data.frame()
}

hchart(imageSizes, hcaes(x = Index, y = Size), type = 'line') %>% 
  hc_xAxis(title = list(text = "Principal Component Index")) %>% 
  hc_yAxis(title = list(text = "Image Size")) %>%   
  hc_title(text = "Image Size vs Princiapl Component Index")


#######################################   10


